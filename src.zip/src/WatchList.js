import React from 'react'
import Navbar from './Navbar';
// import React from 'react';
// import ListingcomonCom from './ListingcomonCom';
// import NavBarPart from '../navbar/NavBarPart';
// import { FaCar } from 'react-icons/fa';
// import './ListingDetails.css';

function Data({shoes}) {
    return (
        <div>
            <div className='watchlist-shoes-card'>
                <div className='Listingdetails_card'>
                    <div className='Listingdetails_img watchlist_img'>
                        <img src={shoes.url} alt={shoes.name} />
                    </div>
                    <div className='ListingList_details'>
                        <div className='Listinglist_name_review'>
                            <div>
                                <p>{shoes.name}</p>
                                <p>Price : {shoes.price}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}


 function WatchList  ({ watchData }) {
  return (
    <div>
      <Navbar />
      <h1 style={{ padding: "100px 0 30px 0", textAlign: "center" }}>WatchList</h1>
      {watchData.length > 0 ? (
        watchData.map((shoes, index) => <Data key={index} shoes={shoes} />)
      ) : (
        <h2 className='WatchList-noitem'>No Items</h2>
      )}
    </div>
  );
};

export default WatchList
