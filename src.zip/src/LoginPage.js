import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Userlogin } from "./App";

function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const {setloginuser,setlogoutuser} = useContext(Userlogin)


  

  const handleLogin = async (e) => {
    e.preventDefault();

    const response = await fetch("http://localhost:1234/users");
    const users = await response.json();

    const user = users.find((user) => user.email === email && user.password === password);

    if (user) {
      setlogoutuser(true)
      alert("Login successful!");

      setloginuser(user.name)
            
      setTimeout(() => {
      navigate('/')
     }, 6100); // Redirect to dashboard
    } else {
      alert("Invalid email or password.");
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100">
      <div className="card p-4 shadow-lg border-0 rounded-3 login-card">
        <h2 className="text-center text-primary">Login</h2>
        <p className="text-center">Enter your details to access your account.</p>

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label"><b>Email</b></label>
            <input type="text" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>

          <div className="mb-3">
            <label className="form-label"><b>Password</b></label>
            <input type="password" className="form-control" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>

          <button type="submit" className="btn btn-primary w-100">Log In</button>
        </form>

        <div className="text-center mt-3">
          <p>Don't have an account? <Link to="/register" className="text-primary">Register Now</Link></p>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
