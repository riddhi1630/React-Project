import logo from './logo.svg';
import './App.css';
import Home from './Home';
// import Content from './Content';
import Footer from './Footer';
import Navbar from './Navbar';
import Serch from './Serch';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import VideoDetails from './VideoDetails';
import About from './About';
import Contact from './Contact';
import LoginPage from './LoginPage'
import RegisterPage from './RegisterPage';
import PhotoDetails from './PhotoDetails';
import AddCard from './AddCard';
import { createContext, useState } from 'react';
import Payment from './Payment';
import OrderConfirm from './OrderConfirm';
// import WatchList from './WatchList';



export const Userlogin = createContext()







function App() {

  const [loginuser,setloginuser] = useState('')
  const [logoutuser,setlogoutuser] = useState(false)
  const [cart, setCart] = useState([]); // Manage cart globally

  // Function to add item to cart
  const addTocard = (photo, quantity, totalPrice) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.photo.id === photo.id);
      if (existingItem) {
        return prevCart.map((item) =>
          item.photo.id === photo.id
            ? { ...item, quantity: item.quantity + quantity, totalPrice: item.totalPrice + totalPrice }
            : item
        );
      } else {
        return [...prevCart, { photo, quantity, totalPrice }];
      }
    });
  };

  

  return (
    <div>
      {/* <Navbar/>
      <Serch/>
      <Home/>
      <Content/>
      <Footer/> */}
      {/* <LoginPage/> */}

      <Userlogin.Provider value={{loginuser,setloginuser,logoutuser,setlogoutuser}}>

      <BrowserRouter>
      
      <Navbar/>
      <Serch/>
        <Routes>
          <Route path='/' element={<Home/>}></Route>
          <Route path="/photodetails/:id" element={<PhotoDetails addToCart={addTocard} />} />
          <Route path='/addcard' element={<AddCard cart={cart} card={[]} />}></Route>
          {/* <Route path='watchlist' element={<WatchList/>}></Route> */}
          <Route path='/payment' element={<Payment/>}></Route>
          <Route path='confirm' element={<OrderConfirm/>}></Route>
          <Route path='/videos' element={<VideoDetails/>}></Route>
          <Route path='/about' element={<About/>}></Route>
          <Route path='/contact' element={<Contact/>}></Route>
          <Route path='/login' element={<LoginPage/>}></Route>
          <Route path='/register' element={<RegisterPage/>}></Route>

          
        </Routes>
      <Footer/> 
      
      </BrowserRouter>

      </Userlogin.Provider>
      

      {/* <BrowserRouter>
      
        <Routes>
         
          <Route path='/login' element={<LoginPage/>}></Route>
        </Routes>
     

      </BrowserRouter> */}




    </div>
  );
}

export default App;
