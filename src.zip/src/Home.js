import { useEffect, useState } from 'react';
import { FaStar } from 'react-icons/fa';
import { Link } from 'react-router-dom'
// FaStar
import './App.css'

function Home() {

  const [items, setItems] = useState([]);

    useEffect(() => {
        fetch("http://localhost:5000/gallery") // JSON server URL
            .then((response) => response.json())
            .then((data) => setItems(data))
            .catch((error) => console.error("Error fetching data:", error));
    }, []);



  return (


    <div>
      <div className="container-fluid tm-container-content tm-mt-60">
        <div className="row mb-4">
            <h2 className="col-6 tm-text-primary">
              Latest Photos
            </h2>
            <div className="col-6 d-flex justify-content-end align-items-center">
              <form  action="true" className="tm-text-primary">
                Page <input type="text" defaultValue={1} size={1} className="tm-input-paging tm-text-primary" /> of 200
              </form>
            </div>
            </div>
        
        {/* <div className="row tm-mb-90 tm-gallery">
          {items.map((item) => (
            <div key={item.id} className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
              <figure className="effect-ming tm-video-item">
                <img src={item.image} alt={item.title} className="img-fluid" />
                <figcaption className="d-flex align-items-center justify-content-center">
                  <h2>{item.title}</h2>
                  <Link to={`/photodetails/${item.id}`}>View more</Link>
                  </figcaption>
              </figure>
              <div className="d-flex justify-content-between tm-text-gray">
                <span className="tm-text-gray-dark">Price {item.price}</span>
                <span>{item.views} views</span>
              </div>
            </div>
           ))}
        </div> */}

        <div className="row tm-mb-90 tm-gallery">
        {items.map((item) => (
          <div key={item.id} className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
            <div className="card shadow-sm border-0">
              <img src={item.image} alt={item.title} className="card-img-top img-fluid" />
              <div className="card-body text-center">
                <h5 className="card-title">{item.title}</h5>
                <div className='car_review'><FaStar/><FaStar/><FaStar/><FaStar/><FaStar/> (5.0)</div>

                <p className="card-text">${item.price}</p>
                <Link to={`/photodetails/${item.id}`} className="btn btn-primary">View Details</Link>
              </div>
            </div>
          </div>
        ))}
      </div>
        {/* row */}
        <div className="row tm-mb-90">
                <div className="col-12 d-flex justify-content-between align-items-center tm-paging-col">
                  <a href="javascript:void(0);" className="btn btn-primary tm-btn-prev mb-2 disabled">Previous</a>
                  <div className="tm-paging d-flex">
                    <a href="javascript:void(0);" className="active tm-paging-link">1</a>
                    <a href="javascript:void(0);" className="tm-paging-link">2</a>
                    <a href="javascript:void(0);" className="tm-paging-link">3</a>
                    <a href="javascript:void(0);" className="tm-paging-link">4</a>
                  </div>
                  <a href="javascript:void(0);" className="btn btn-primary tm-btn-next">Next Page</a>
                </div>
              </div>
        {/* </div> */}

      </div>

    </div>



  )
}

export default Home
