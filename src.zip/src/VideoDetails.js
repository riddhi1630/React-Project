import React from 'react'

function VideoDetails() {
    return (
        <div>

            <div className="container-fluid tm-container-content tm-mt-60">
                <div className="row mb-4">
                    <h2 className="col-12 tm-text-primary">Video title goes here</h2>
                </div>
                <div className="row tm-mb-90">
                    <div className="col-xl-8 col-lg-7 col-md-6 col-sm-12">
                        <video autoPlay muted loop controls id="tm-video">
                            <source src="video/hero.mp4" type="video/mp4" />
                        </video>
                    </div>
                    <div className="col-xl-4 col-lg-5 col-md-6 col-sm-12">
    <div className="tm-bg-gray tm-photo-details">
        <p className="mb-4">
            Discover stunning photography with high-resolution quality. Our collection features breathtaking images captured by talented photographers worldwide. Browse, download, and enhance your projects with our premium selection.
        </p>
        <div className="text-center mb-5">
            <a href="#" className="btn btn-primary tm-btn-big">Download</a>
        </div>
        <div className="mb-4 d-flex flex-wrap">
            <div className="mr-4 mb-2">
                <span className="tm-text-gray-dark">Resolution: </span><span className="tm-text-primary">3840x2160</span>
            </div>
            <div className="mr-4 mb-2">
                <span className="tm-text-gray-dark">Format: </span><span className="tm-text-primary">JPG</span>
            </div>
            <div>
                <span className="tm-text-gray-dark">Size: </span><span className="tm-text-primary">2.5 MB</span>
            </div>
        </div>
        <div className="mb-4">
            <h3 className="tm-text-gray-dark mb-3">License</h3>
            <p>Free for both personal and commercial use. No attribution required.</p>
        </div>
        <div>
            <h3 className="tm-text-gray-dark mb-3">Tags</h3>
            <a href="#" className="tm-text-primary mr-4 mb-2 d-inline-block">Landscape</a>
            <a href="#" className="tm-text-primary mr-4 mb-2 d-inline-block">Nature</a>
            <a href="#" className="tm-text-primary mr-4 mb-2 d-inline-block">Sunset</a>
            <a href="#" className="tm-text-primary mr-4 mb-2 d-inline-block">Cityscape</a>
            <a href="#" className="tm-text-primary mr-4 mb-2 d-inline-block">Abstract</a>
            <a href="#" className="tm-text-primary mr-4 mb-2 d-inline-block">Portrait</a>
            <a href="#" className="tm-text-primary mr-4 mb-2 d-inline-block">Architecture</a>
        </div>
    </div>
</div>

                </div>
                <div className="row mb-4">
                    <h2 className="col-12 tm-text-primary">
                        Related Videos
                    </h2>
                </div>
                <div className="row mb-3 tm-gallery">
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                        <figure className="effect-ming tm-video-item">
                            <img src="img/img-1.jpg" alt="Image" className="img-fluid" />
                            <figcaption className="d-flex align-items-center justify-content-center">
                                <h2>New York</h2>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                        <div className="d-flex justify-content-between tm-text-gray">
                            <span className="tm-text-gray-light">3250 Price</span>
                            <span>31,444 views</span>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                        <figure className="effect-ming tm-video-item">
                            <img src="img/img-2.jpg" alt="Image" className="img-fluid" />
                            <figcaption className="d-flex align-items-center justify-content-center">
                                <h2>New York</h2>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                        <div className="d-flex justify-content-between tm-text-gray">
                            <span className="tm-text-gray-light">5550 Price</span>
                            <span>65,345 views</span>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                        <figure className="effect-ming tm-video-item">
                            <img src="img/img-3.jpg" alt="Image" className="img-fluid" />
                            <figcaption className="d-flex align-items-center justify-content-center">
                                <h2>New York</h2>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                        <div className="d-flex justify-content-between tm-text-gray">
                            <span className="tm-text-gray-light">2650 Price</span>
                            <span>12,460 views</span>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                        <figure className="effect-ming tm-video-item">
                            <img src="img/img-4.jpg" alt="Image" className="img-fluid" />
                            <figcaption className="d-flex align-items-center justify-content-center">
                                <h2>New York</h2>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                        <div className="d-flex justify-content-between tm-text-gray">
                            <span className="tm-text-gray-light">2499 Price</span>
                            <span>11,402 views</span>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                        <figure className="effect-ming tm-video-item">
                            <img src="img/img-6.jpg" alt="Image" className="img-fluid" />
                            <figcaption className="d-flex align-items-center justify-content-center">
                                <h2>New York</h2>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                        <div className="d-flex justify-content-between tm-text-gray">
                            <span className="tm-text-gray-light">1599 Price</span>
                            <span>12,580 views</span>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                        <figure className="effect-ming tm-video-item">
                            <img src="img/img-8.jpg" alt="Image" className="img-fluid" />
                            <figcaption className="d-flex align-items-center justify-content-center">
                                <h2>New York</h2>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                        <div className="d-flex justify-content-between tm-text-gray">
                            <span className="tm-text-gray-light">4999 Price</span>
                            <span>11,300 views</span>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                        <figure className="effect-ming tm-video-item">
                            <img src="img/img-10.jpg" alt="Image" className="img-fluid" />
                            <figcaption className="d-flex align-items-center justify-content-center">
                                <h2>New York</h2>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                        <div className="d-flex justify-content-between tm-text-gray">
                            <span className="tm-text-gray-light">6999 Price</span>
                            <span>23,380 views</span>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                        <figure className="effect-ming tm-video-item">
                            <img src="img/11.jpg" alt="Image" className="img-fluid" />
                            <figcaption className="d-flex align-items-center justify-content-center">
                                <h2>New York</h2>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                        <div className="d-flex justify-content-between tm-text-gray">
                            <span className="tm-text-gray-light">4699 Price</span>
                            <span>20,79 views</span>
                        </div>
                    </div>
                </div> {/* row */}
            </div>


        </div>
    )
}

export default VideoDetails
