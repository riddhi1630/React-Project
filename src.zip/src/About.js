import React from 'react';

function About() {
    return (
        <div className="container-fluid tm-mt-60">
            <div className="row mb-4">
                <h2 className="col-12 tm-text-primary">About Our Gallery</h2>
            </div>
            <div className="row tm-mb-74 tm-row-1640">
                <div className="col-lg-5 col-md-6 col-12 mb-3">
                    <img src="img/about.jpg" alt="Gallery Showcase" className="img-fluid" />
                </div>
                <div className="col-lg-7 col-md-6 col-12">
                    <div className="tm-about-img-text">
                        <p className="mb-4">
                            Welcome to our online gallery, where creativity meets convenience. Our platform showcases a curated selection of high-quality images, perfect for artists, designers, and content creators. Browse our collection, explore unique visuals, and find the perfect image for your needs.
                        </p>
                        <p>
                            Our mission is to support talented photographers and provide customers with easy access to beautiful imagery. Whether you need visuals for personal or commercial use, we make it simple to discover and purchase stunning photographs.
                        </p>
                    </div>
                </div>
            </div>

            <div className="row tm-mb-50">
                <div className="col-md-6 col-12">
                    <h2 className="tm-text-primary mb-4">Why Choose Us?</h2>
                    <p className="mb-4">
                        Our gallery stands out with its diverse collection, affordable pricing, and user-friendly experience. We ensure each photo is carefully curated to meet high-quality standards, making it easy for you to find exactly what you need.
                    </p>
                </div>
                <div className="col-md-6 col-12">
                    <h2 className="tm-text-primary mb-4">How It Works</h2>
                    <p className="mb-4">
                        Simply browse our collection, select an image, and proceed to checkout. We offer multiple payment options for a seamless experience. Once purchased, you’ll receive high-resolution downloads instantly.
                    </p>
                </div>
            </div>

            <div className="row tm-mb-50">
                <div className="col-md-4 col-12">
                    <h2 className="tm-text-primary mb-4">Diverse Collection</h2>
                    <p>Explore a wide range of categories, from landscapes and portraits to abstract art. Our collection is updated regularly to keep up with the latest trends.</p>
                </div>
                <div className="col-md-4 col-12">
                    <h2 className="tm-text-primary mb-4">Affordable Pricing</h2>
                    <p>We believe high-quality imagery should be accessible to everyone. Our pricing is transparent and budget-friendly, with options for personal and commercial use.</p>
                </div>
                <div className="col-md-4 col-12">
                    <h2 className="tm-text-primary mb-4">Easy Access</h2>
                    <p>Our platform is designed for convenience, allowing users to quickly find, purchase, and download images hassle-free.</p>
                </div>
            </div>
        </div>
    );
}

export default About;