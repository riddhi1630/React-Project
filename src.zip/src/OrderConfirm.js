import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";

function OrderConfirm() {
  const location = useLocation();
  const navigate = useNavigate();
  const { cartItems, totalPrice } = location.state || { cartItems: [], totalPrice: "0.00" };

  const [paymentMethod, setPaymentMethod] = useState("");

  // Function to handle order confirmation
  const handleOrderConfirmation = () => {
    if (!paymentMethod) {
      alert("Please select a payment method!");
      return;
    }
    alert("Order placed successfully! 🎉");
    navigate("/"); // Redirect to home or orders page after confirmation
  };

  return (
    <div className="container">
      <h2 className="text-center mb-3">Select Payment Method</h2>

      <div className="card p-4 shadow-sm border-0">
        <h4 className="mb-3">Total Amount: <strong>{totalPrice}</strong></h4>

        {/* Payment Methods */}
        <div className="form-check">
          <input
            className="form-check-input"
            type="radio"
            name="paymentMethod"
            value="Cash on Delivery"
            id="cod"
            onChange={(e) => setPaymentMethod(e.target.value)}
          />
          <label className="form-check-label" htmlFor="cod">Cash on Delivery</label>
        </div>

        <div className="form-check">
          <input
            className="form-check-input"
            type="radio"
            name="paymentMethod"
            value="Google Pay"
            id="gpay"
            onChange={(e) => setPaymentMethod(e.target.value)}
          />
          <label className="form-check-label" htmlFor="gpay">Google Pay</label>
        </div>

        <div className="form-check">
          <input
            className="form-check-input"
            type="radio"
            name="paymentMethod"
            value="Credit/Debit Card"
            id="card"
            onChange={(e) => setPaymentMethod(e.target.value)}
          />
          <label className="form-check-label" htmlFor="card">Credit/Debit Card</label>
        </div>

        {/* Confirm Order Button */}
        <div className="text-center mt-4">
          <button className="btn btn-success btn-lg w-10 rounded-pill mt-2" onClick={handleOrderConfirmation}>
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
}

export default OrderConfirm;
