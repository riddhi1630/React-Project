import { useLocation, useNavigate } from "react-router-dom";
import { useState, useMemo } from "react";

function PaymentPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState(location.state?.cartItems || []);

  // Function to update quantity and total price
  const handleQuantityChange = (index, change) => {
    setCartItems((prevCart) =>
      prevCart.map((item, i) =>
        i === index
          ? {
              ...item,
              quantity: Math.max(1, item.quantity + change),
              totalPrice: (Math.max(1, item.quantity + change) * parseFloat(item.photo.price)).toFixed(2),
            }
          : item
      )
    );
  };

  // Remove item from cart
  const handleRemoveItem = (index) => {
    setCartItems((prevCart) => prevCart.filter((_, i) => i !== index));
  };

  // Calculate Total Items and Total Price
  const totalItems = useMemo(() => cartItems.reduce((sum, item) => sum + item.quantity, 0), [cartItems]);
  const totalPrice = useMemo(
    () => cartItems.reduce((sum, item) => sum + parseFloat(item.totalPrice), 0).toFixed(2),
    [cartItems]
  );

  return (
    <div className="container">
      <h2 className="text-center mb-3">Payment Details</h2>

      {/* Cart Summary */}
      <div className="card mb-3 p-2 text-center shadow-sm border-0">
        <h6 className="mb-1"><strong>Total Items:</strong> {totalItems}</h6>
        <h6><strong>Total Price:</strong> {totalPrice}</h6>
      </div>

      {/* Cart Items in Row Format */}
      <div className="table-responsive">
        <table className="table table-bordered">
          <thead className="table-light">
            <tr>
              <th>Image</th>
              <th>Title</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Total</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {cartItems.map((item, index) => (
              <tr key={item.photo.id}>
                <td>
                  <img 
                    src={`http://localhost:5000/${item.photo.image}`} 
                    alt={item.photo.title} 
                    style={{ maxHeight: "50px", objectFit: "cover" }}
                  />
                </td>
                <td>{item.photo.title}</td>
                <td>{parseFloat(item.photo.price).toFixed(2)}</td>
                <td>
                  <button className="btn btn-sm btn-outline-secondary" onClick={() => handleQuantityChange(index, -1)}>-</button>
                  <span className="mx-2">{item.quantity}</span>
                  <button className="btn btn-sm btn-outline-secondary" onClick={() => handleQuantityChange(index, 1)}>+</button>
                </td>
                <td>{item.totalPrice}</td>
                <td>
                  <button className="btn btn-danger btn-sm" onClick={() => handleRemoveItem(index)}>Remove</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Confirm Order Button */}
      <div className="text-center mt-4">
        <button 
          className="btn btn-success btn-lg w-10 rounded-pill mt-2"
          onClick={() => navigate("/confirm", { state: { cartItems, totalPrice } })}
        >
          Confirm Order
        </button>
      </div>
    </div>
  );
}

export default PaymentPage;
