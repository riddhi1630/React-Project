import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

function PhotoDetails({ addToCart }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [photo, setPhoto] = useState({});
  const [quantity, setQuantity] = useState(1);
  const [totalPrice, setTotalPrice] = useState(0);

  useEffect(() => {
    fetch(`http://localhost:5000/gallery/${id}`)
      .then((response) => response.json())
      .then((data) => {
        setPhoto(data);
        setTotalPrice(data.price);
      });
  }, [id]);

  const handleQuantityChange = (change) => {
    setQuantity((prevQuantity) => {
      const newQuantity = Math.max(1, prevQuantity + change);
      setTotalPrice(newQuantity * photo.price);
      return newQuantity;
    });
  };

  const handleAddToCart = () => {
    addToCart(photo, quantity, totalPrice);
    navigate("/addcard");
  };

  return (
    <div className="container d-flex justify-content-center align-items-center vh-50">
      <div className="card shadow-lg border-1 p-4 rounded-2" style={{ width: "25rem" }}>
        <img src={`http://localhost:5000/${photo.image}`} className="card-img-top rounded-2" alt={photo.title} style={{ maxHeight: "400px"}} />
        <div className="card-body text-center">
          <h4 className="card-title fw-bold">{photo.title}</h4>
          <p className="text-muted">{photo.description}</p>
          <p style={{ fontSize: "20px", color: "revert" }}><strong>Price:</strong> {totalPrice}</p> 
          <p><strong>Views:</strong> {photo.views}</p>
          <div className="d-flex justify-content-center align-items-center my-2">
            <button className="btn btn-outline-secondary rounded-pill px-3" onClick={() => handleQuantityChange(-1)}>-</button>
            <span className="mx-3 fs-5 fw-bold">{quantity}</span>
            <button className="btn btn-outline-secondary rounded-pill px-3" onClick={() => handleQuantityChange(1)}>+</button>
          </div>
          <button className="btn btn-success btn-lg w-100 rounded-pill mt-2" onClick={handleAddToCart}>
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}

export default PhotoDetails;
