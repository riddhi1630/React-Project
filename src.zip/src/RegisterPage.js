import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function RegisterPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    // Check if email already exists
    const checkResponse = await fetch(`http://localhost:1234/users?email=${email}`);
    const existingUsers = await checkResponse.json();
    if (existingUsers.length > 0) {
      alert("Email already registered! Please log in.");
      return;
    }

    const userData = { email,password };

    const response = await fetch("http://localhost:1234/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userData),
    });

    if (response.ok) {
      alert("Registration successful! Please log in.");
      navigate("/login"); // Redirect to login page
    } else {
      alert("Error registering user.");
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100">
      <div className="card p-4 shadow-lg border-0 rounded-3 register-card">
        <h2 className="text-center text-primary">Register</h2>
        <p className="text-center">Fill in the details to create an account.</p>

        <form onSubmit={handleRegister}>
          <div className="mb-3">
            <label className="form-label"><b>Email</b></label>
            <input type="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>

          <div className="mb-3">
            <label className="form-label"><b>Address</b></label>
            <input type="text" className="form-control" required />
          </div>

          <div className="mb-3">
            <label className="form-label"><b>Password</b></label>
            <input type="password" className="form-control" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>

          <button type="submit" className="btn btn-primary w-100">Register</button>
        </form>

        <div className="text-center mt-3">
          <p>Already have an account? <Link to="/login" className="text-primary">Log in</Link>.</p>
        </div>
      </div>
    </div>
  );
}

export default RegisterPage;
