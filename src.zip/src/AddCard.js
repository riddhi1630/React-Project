import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";

function AddCard({ cart }) {
  const [cartItems, setCartItems] = useState(cart);
  const navigate = useNavigate();


  // Function to update quantity and price
  const handleQuantityChange = (index, change) => {
    setCartItems((prevCart) =>
      prevCart.map((item, i) =>
        i === index
          ? {
              ...item,
              quantity: Math.max(1, item.quantity + change),
              totalPrice: (Math.max(1, item.quantity + change) * parseFloat(item.photo.price)).toFixed(2),
            }
          : item
      )
    );
  };

  // Calculate Total Items and Total Price
  const totalItems = useMemo(() => cartItems.reduce((sum, item) => sum + item.quantity, 0), [cartItems]);
  const totalPrice = useMemo(
    () => cartItems.reduce((sum, item) => sum + parseFloat(item.totalPrice), 0).toFixed(2),
    [cartItems]
  );

  if (cartItems.length === 0) {
    return <h2 className="text-center">No items in the cart</h2>;
  }

  return (
    <div className="container">
      <h2 className="text-center mb-3">Your Shopping</h2>

      {/* Cart Summary Section */}
      <div className="card mb-3 p-2 text-center shadow-sm border-0">
        <h6 className="mb-1"><strong>Total Items:</strong> {totalItems}</h6>
        <h6><strong>Total Price:</strong> {totalPrice}</h6>
      </div>

      <div className="row justify-content-center">
        {cartItems.map((item, index) => (
          <div key={item.photo.id} className="col-md-3 col-sm-6 mb-2">
            <div className="card shadow-sm border-0 p-3 rounded-2">
              <img 
                src={`http://localhost:5000/${item.photo.image}`} 
                className="card-img-top rounded-2" 
                alt={item.photo.title} 
                style={{ maxHeight: "200px", objectFit: "cover" }}
              />
              <div className="card-body text-center p-2">
                <h6 className="card-title fw-bold">{item.photo.title}</h6>
                <p className="text-muted small">{item.photo.description}</p>
                <p className="mb-1"><strong>Price:</strong> {parseFloat(item.photo.price).toFixed(2)}</p>
                <p className="mb-1"><strong>Quantity:</strong> {item.quantity}</p>
                <p className="mb-1"><strong>Total:</strong> {item.totalPrice}</p>
                <div className="d-flex justify-content-center align-items-center">
                  <button className="btn btn-outline-secondary btn-sm rounded-circle px-2" onClick={() => handleQuantityChange(index, -1)}>-</button>
                  <span className="mx-2 fs-6 fw-bold">{item.quantity}</span>
                  <button className="btn btn-outline-secondary btn-sm rounded-circle px-2" onClick={() => handleQuantityChange(index, 1)}>+</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Proceed to Payment Button */}
      <div className="text-center mt-2">
        <button 
          className="btn btn-success btn-lg w-10 rounded-pill mt-2"
          onClick={() => navigate("/payment", { state: { cartItems } })}>
          Proceed to Payment
        </button>
      </div>
    </div>
  );
}

export default AddCard;
