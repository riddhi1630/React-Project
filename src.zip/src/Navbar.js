import React, { useContext } from 'react'
import { Link } from 'react-router-dom'
import { Userlogin } from './App'

function Navbar() {

  const {logoutuser,setlogoutuser,setloginuser}= useContext(Userlogin)

  // const  handleclick = ()=>{
  //   setshow(!show)
  // }

  const Logoutuser = ()=>{
    alert("Are you sure?")
    setloginuser('')
    // setwatchlistdata([])
    setlogoutuser(false)
  }


  return (
    <div>




<nav className="navbar navbar-expand-lg">
  <div className="container-fluid">
    <a className="navbar-brand" href="#">
      <i className="fas fa-film mr-2" />
      Catalog-Z
    </a>
    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <i className="fas fa-bars" />
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav ml-auto mb-2 mb-lg-0">
      {/* <li> <Link to={'/watchlist'} className='Link_tag_text'>WatchList</Link></li> */}
        <li className="nav-item" >
          <Link className="nav-link nav-link-1 "  to="/">Photos</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link nav-link-2" to="/videos">Videos</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link nav-link-3" to="/about">About</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link nav-link-4" to="/contact">Contact</Link>
        </li>
        <div className="nav-item">
              {logoutuser ? (
                <button className="btn btn-danger logout-btn" onClick={Logoutuser}>
                  Logout
                </button>
              ) : (
                <div>
                  {/* <button className="btn  login-btn"> */}
                    <Link to={'/login'} className="nav-link nav-link-4">
                      Login
                    </Link>
                  {/* </button> */}
                  {/* <button className="btn register-btn"> */}
                    {/* <Link to={'/register'} className="nav-link nav-link-4">
                       Register
                    </Link> */}
                  {/* </button> */}
                </div>
              )}
            </div>
        
      </ul>
    </div>
  </div>
  
</nav>


{/* <li className="nav-item">
          <Link className="nav-link nav-link-4" to="/login">Login</Link>
        </li> */}
      
    </div>
  )
}

export default Navbar
